#pragma once
#include <vector>
#include <string>

using namespace std;

class Visualizer {
public:
    static void showArray(const string& title, const vector<int>& arr, size_t maxShow = 25);
    static void showMessage(const string& msg);
    static void separator();
};