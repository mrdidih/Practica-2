#include "RadixSort.h"
#include "Visualizer.h"
#include <algorithm>
#include <vector>

using namespace std;

void RadixSort::sort(vector<int>& arr) {
    if (arr.empty()) return;
    int maxVal = *max_element(arr.begin(), arr.end());

    for (int exp = 1; maxVal / exp > 0; exp *= 10) {
        vector<int> output(arr.size());
        vector<int> count(10, 0);

        for (int num : arr)
            count[(num / exp) % 10]++;

        for (int i = 1; i < 10; i++)
            count[i] += count[i-1];

        for (int i = (int)arr.size()-1; i >= 0; i--) {
            output[count[(arr[i]/exp)%10] - 1] = arr[i];
            count[(arr[i]/exp)%10]--;
        }
        arr = move(output);
    }
}

void RadixSort::sortWithVisualization(vector<int>& arr) {
    Visualizer::showMessage("=== INICIANDO Radix Sort (LSD) ===");
    Visualizer::showArray("Arreglo Original", arr);
    sort(arr);
    Visualizer::showArray("Arreglo Ordenado - Radix Sort", arr);
    Visualizer::showMessage("=== Radix Sort COMPLETADO ===\n");
}

string RadixSort::getComplexityInfo() {
    return "O(d * (n + 10))  [d = número de dígitos]";
}