#include "Benchmark.h"
#include "DialSort.h"
#include "RadixSort.h"
#include "DataGenerator.h"
#include "Visualizer.h"
#include <chrono>
#include <numeric>
#include <fstream>
#include <iomanip>
#include <iostream>     // ← Faltaba
#include <cmath>        // ← Para sqrt()

using namespace std;
using namespace std::chrono;

BenchmarkResult Benchmark::runTest(const string& algoName, size_t n, int universe, int runs) {
    vector<double> times;
    for (int i = 0; i < runs; ++i) {
        auto data = DataGenerator::generate(n, 0, universe-1, DataGenerator::Distribution::Uniform);
        auto start = high_resolution_clock::now();

        if (algoName == "DialSort")
            DialSort::sort(data);
        else
            RadixSort::sort(data);

        auto end = high_resolution_clock::now();
        times.push_back(duration_cast<milliseconds>(end - start).count());
    }

    double mean = accumulate(times.begin(), times.end(), 0.0) / runs;
    double variance = 0.0;
    for (double t : times) variance += (t - mean)*(t - mean);
    double stddev = sqrt(variance / runs);

    BenchmarkResult r;
    r.algorithm = algoName;
    r.n = n;
    r.universe = universe;
    r.meanTimeMs = mean;
    r.stdDevMs = stddev;
    r.throughput = (n / mean) * 1000.0;
    r.memoryKB = 0;
    return r;
}

void Benchmark::runFullBenchmark() {
    Visualizer::separator();
    cout << "EJECUTANDO BENCHMARK COMPLETO (DialSort vs RadixSort)\n\n";

    vector<size_t> sizes = {100000, 500000, 1000000};
    vector<int> universes = {10000, 100000, 1000000};

    ofstream csv("benchmark_results.csv");
    csv << "Algorithm,N,Universe,MeanTime_ms,StdDev,Throughput\n";

    for (size_t n : sizes) {
        for (int u : universes) {
            cout << "Probando n = " << n << ", U = " << u << "\n";
            auto r1 = runTest("DialSort", n, u);
            auto r2 = runTest("RadixSort", n, u);

            cout << "  DialSort  : " << r1.meanTimeMs << " ms\n";
            cout << "  RadixSort : " << r2.meanTimeMs << " ms\n\n";

            csv << r1.algorithm << "," << r1.n << "," << r1.universe << ","
                << r1.meanTimeMs << "," << r1.stdDevMs << "," << r1.throughput << "\n";
            csv << r2.algorithm << "," << r2.n << "," << r2.universe << ","
                << r2.meanTimeMs << "," << r2.stdDevMs << "," << r2.throughput << "\n";
        }
    }
    cout << "Benchmark terminado. Resultados guardados en benchmark_results.csv\n";
}