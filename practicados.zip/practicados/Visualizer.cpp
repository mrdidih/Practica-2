#include "Visualizer.h"
#include <iostream>
#include <iomanip>

using namespace std;

void Visualizer::showArray(const string& title, const vector<int>& arr, size_t maxShow) {
    cout << "\n" << title << " (" << arr.size() << " elementos):\n";
    for (size_t i = 0; i < min(maxShow, arr.size()); ++i) {
        cout << arr[i] << " ";
    }
    if (arr.size() > maxShow) cout << "... [+" << (arr.size() - maxShow) << "]";
    cout << "\n";
}

void Visualizer::showMessage(const string& msg) {
    cout << msg << "\n";
}

void Visualizer::separator() {
    cout << string(80, '=') << "\n";
}