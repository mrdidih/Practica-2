#include "DataGenerator.h"
#include <random>
#include <fstream>
#include <algorithm>

using namespace std;

vector<int> DataGenerator::generate(size_t n, int minVal, int maxVal, Distribution dist) {
    vector<int> data(n);
    random_device rd;
    mt19937 gen(rd());

    if (dist == Distribution::Uniform) {
        uniform_int_distribution<> dis(minVal, maxVal);
        for (auto& x : data) x = dis(gen);
    } else if (dist == Distribution::Skewed) {
        uniform_int_distribution<> dis(minVal, maxVal/2);
        for (auto& x : data) x = dis(gen);
    } else if (dist == Distribution::FewUnique) {
        uniform_int_distribution<> dis(0, 50);
        for (auto& x : data) x = dis(gen);
    } else if (dist == Distribution::Sorted) {
        uniform_int_distribution<> dis(minVal, maxVal);
        for (auto& x : data) x = dis(gen);
        sort(data.begin(), data.end());
    } else if (dist == Distribution::Reverse) {
        uniform_int_distribution<> dis(minVal, maxVal);
        for (auto& x : data) x = dis(gen);
        sort(data.rbegin(), data.rend());
    }
    return data;
}

void DataGenerator::saveToFile(const vector<int>& data, const string& filename) {
    ofstream out(filename);
    for (int x : data) out << x << "\n";
}