#pragma once
#include <vector>
#include <string>

using namespace std;

struct BenchmarkResult {
    string algorithm;
    size_t n;
    int universe;
    double meanTimeMs;
    double stdDevMs;
    double throughput;
    size_t memoryKB;
};

class Benchmark {
public:
    static void runFullBenchmark();
    static BenchmarkResult runTest(const string& algoName, size_t n, int universe, int runs = 5);
};