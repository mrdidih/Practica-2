#include "DialSort.h"
#include "Visualizer.h"
#include <algorithm>
#include <iostream>

using namespace std;

void DialSort::sort(vector<int>& arr) {
    if (arr.empty()) return;
    int maxVal = *max_element(arr.begin(), arr.end());
    if (maxVal < 0) maxVal = 0;

    vector<int> count(maxVal + 1, 0);
    for (int num : arr) count[num]++;

    int index = 0;
    for (int i = 0; i <= maxVal; ++i) {
        while (count[i] > 0) {
            arr[index++] = i;
            count[i]--;
        }
    }
}

void DialSort::sortWithVisualization(vector<int>& arr) {
    Visualizer::showMessage("=== INICIANDO DialSort (Counting Sort) ===");
    Visualizer::showArray("Arreglo Original", arr);
    sort(arr);
    Visualizer::showArray("Arreglo Ordenado - DialSort", arr);
    Visualizer::showMessage("=== DialSort COMPLETADO ===\n");
}

string DialSort::getComplexityInfo() {
    return "O(n + U)  [U = tamaño del universo]";
}