#include <iostream>
#include "DialSort.h"
#include "RadixSort.h"
#include "Benchmark.h"
#include "Visualizer.h"
#include "DataGenerator.h"

using namespace std;

int main() {
    Visualizer::separator();
    cout << "PRACTICA II - DIAL SORT vs RADIX SORT\n";
    cout << "Data Structures and Algorithms - Juan Munoz\n\n";

    int opt;
    do {
        cout << "1. Visualizar DialSort\n";
        cout << "2. Visualizar Radix Sort\n";
        cout << "3. Ejecutar Benchmark Completo\n";
        cout << "4. Salir\n";
        cout << "Seleccione: ";
        cin >> opt;

        if (opt == 1) {
            auto data = DataGenerator::generate(30, 0, 200, DataGenerator::Distribution::Uniform);
            DialSort::sortWithVisualization(data);
        }
        else if (opt == 2) {
            auto data = DataGenerator::generate(30, 0, 200, DataGenerator::Distribution::Uniform);
            RadixSort::sortWithVisualization(data);
        }
        else if (opt == 3) {
            Benchmark::runFullBenchmark();
        }
    } while (opt != 4);

    cout << "\nPrograma finalizado.\n";
    return 0;
}