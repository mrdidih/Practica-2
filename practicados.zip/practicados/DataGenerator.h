#pragma once
#include <vector>
#include <string>

using namespace std;

class DataGenerator {
public:
    enum class Distribution { Uniform, Skewed, FewUnique, Sorted, Reverse };

    static vector<int> generate(size_t n, int minVal, int maxVal, Distribution dist = Distribution::Uniform);
    static void saveToFile(const vector<int>& data, const string& filename);
};