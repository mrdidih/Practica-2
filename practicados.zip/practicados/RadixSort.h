#pragma once
#include <vector>
#include <string>

using namespace std;

class RadixSort {
public:
    static void sort(vector<int>& arr);
    static void sortWithVisualization(vector<int>& arr);
    static string getComplexityInfo();
    static string getName() { return "Radix Sort (LSD)"; }
};